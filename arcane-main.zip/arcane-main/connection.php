<?php
    $servername = "localhost";
    $username = "id17980038_mark";
    $password = "Arcane2.0.0.0";
    $dbname = "id17980038_arcane";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
?>